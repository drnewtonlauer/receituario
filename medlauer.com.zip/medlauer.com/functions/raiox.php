<?php include"config.php";
session_start();


 if (!empty( $_POST['chk0'])) { $_SESSION['solicitacao'][] = $_POST['chk0'];} 
if (!empty( $_POST['chk1'])) { $_SESSION['solicitacao'][] = $_POST['chk1'];} 
if (!empty( $_POST['chk2'])) { $_SESSION['solicitacao'][] = $_POST['chk2'];} 
if (!empty( $_POST['chk3'])) { $_SESSION['solicitacao'][] = $_POST['chk3'];} 
if (!empty( $_POST['chk4'])) { $_SESSION['solicitacao'][] = $_POST['chk4'];} 
if (!empty( $_POST['chk5'])) { $_SESSION['solicitacao'][] = $_POST['chk5'];} 
if (!empty( $_POST['chk6'])) { $_SESSION['solicitacao'][] = $_POST['chk6'];} 
if (!empty( $_POST['chk7'])) { $_SESSION['solicitacao'][] = $_POST['chk7'];} 
if (!empty( $_POST['chk8'])) { $_SESSION['solicitacao'][] = $_POST['chk8'];} 
if (!empty( $_POST['chk9'])) { $_SESSION['solicitacao'][] = $_POST['chk9'];} 
if (!empty( $_POST['chk10'])) { $_SESSION['solicitacao'][] = $_POST['chk10'];} 
if (!empty( $_POST['chk11'])) { $_SESSION['solicitacao'][] = $_POST['chk11'];} 
if (!empty( $_POST['chk12'])) { $_SESSION['solicitacao'][] = $_POST['chk12'];} 
if (!empty( $_POST['chk13'])) { $_SESSION['solicitacao'][] = $_POST['chk13'];} 
if (!empty( $_POST['chk14'])) { $_SESSION['solicitacao'][] = $_POST['chk14'];} 
if (!empty( $_POST['chk15'])) { $_SESSION['solicitacao'][] = $_POST['chk15'];} 
if (!empty( $_POST['chk16'])) { $_SESSION['solicitacao'][] = $_POST['chk16'];} 
if (!empty( $_POST['chk17'])) { $_SESSION['solicitacao'][] = $_POST['chk17'];} 
if (!empty( $_POST['chk18'])) { $_SESSION['solicitacao'][] = $_POST['chk18'];} 
if (!empty( $_POST['chk19'])) { $_SESSION['solicitacao'][] = $_POST['chk19'];} 
if (!empty( $_POST['chk20'])) { $_SESSION['solicitacao'][] = $_POST['chk20'];} 
if (!empty( $_POST['chk21'])) { $_SESSION['solicitacao'][] = $_POST['chk21'];} 
if (!empty( $_POST['chk22'])) { $_SESSION['solicitacao'][] = $_POST['chk22'];} 
if (!empty( $_POST['chk23'])) { $_SESSION['solicitacao'][] = $_POST['chk23'];} 
if (!empty( $_POST['chk24'])) { $_SESSION['solicitacao'][] = $_POST['chk24'];} 
if (!empty( $_POST['chk25'])) { $_SESSION['solicitacao'][] = $_POST['chk25'];} 
if (!empty( $_POST['chk26'])) { $_SESSION['solicitacao'][] = $_POST['chk26'];} 
if (!empty( $_POST['chk27'])) { $_SESSION['solicitacao'][] = $_POST['chk27'];} 



 header("Location:../imprimirsol.php");
?>