<?php	$footer = '
<table width="600px" class="table">
<tr><td  valign=top>
<table  class="table" border="0" width="50%" style="border-width: 2px;border-style: solid;border-color:black;">
	<tr><td colspan="2" style="padding: 2px 2px 2px 2px;" align="center"><font size="3" >IDENTIFICAÇÃO DO COMPRADOR</td></tr>
	
<tr><td  style="padding: 2px 2px 2px 2px;"><font size="3" >Nome:</td><td> </td></tr>
<tr><td  style="padding: 2px 2px 2px 2px;"><font size="3" >RG: </td><td></td></tr>
<tr><td  style="padding: 2px 2px 2px 2px;"><font size="3" >Endereço:</td><td> </td></tr>
<tr><td  style="padding: 2px 2px 2px 2px;"><font size="3" >Telefone:</td><td> </td></tr>
<tr><td  style="padding: 2px 2px 2px 2px;"><font size="3" >Cidade e UF: </td><td></td></tr>
	</table>
</td><td>
<table class="table" border="0"  width="50%" style="border-width: 2px;border-style: solid;border-color:black;">
	<tr><td style="padding: 2px 2px 2px 2px;" align="center"><font size="3" >IDENTIFICAÇÃO DO FORNCEDOR</td></tr>
	<tr><td  style="padding: 2px 2px 2px 2px;"><br></td></tr>
	<tr><td  style="padding: 0px 2px 0px 2px;"  align="center"><font size="3" >____________________<BR>DATA:</td></tr>


<tr><td  style="padding: 0px 2px 0px 2px;"><br></td></tr>
<tr><td  style="padding: 0px 2px 0px 2px;" align="center"><font size="3" >____________________<BR>ASSINATURA DO FARMACÊUTICO</td></tr>
</table>
					
</td></tr></table>'?>
