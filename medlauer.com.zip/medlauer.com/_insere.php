<?php
include("functions/config.php");
session_start(); 
$_SESSION['nome_av'] = $_GET['valor'];



?>